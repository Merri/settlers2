Merri's New Greenland texture set
---------------------------------
Backup/rename old one before copying:

TEX5.LBM -> \SETTLER2\GFX\TEXTURES


Flow of Lava
------------
FLOWLAVA.SWD -> \SETTLER2\WORLDS


\SETTLER2\ = path of your The Settlers II installation, GOG.com version default path is:
C:\Program Files\GOG.com\Settlers 2 GOLD\